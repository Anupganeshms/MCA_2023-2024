package com.example.restful_demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
