package com.example.lab3;

import java.util.*;

import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/books")
public class BookController {
	
	private final List<Book> books = new ArrayList<Book>();
	
	@GetMapping
	public List<Book> getAllBooks() {
		return books;
	}
	
	@PostMapping
	public Book addBook(@RequestBody Book book) {
		books.add(book);
		return book;
	}
}
