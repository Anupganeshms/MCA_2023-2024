package com.example.lab3_practice;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class SecondActivity extends AppCompatActivity {

    TextView text_view;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        text_view = findViewById(R.id.textView3);

        Intent intent = getIntent();
        String str2 = intent.getStringExtra("message");
        text_view.setText(str2);

    }
}