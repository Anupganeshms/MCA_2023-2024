package com.example.labprogram5;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {


    EditText usernameText,passwordText;
    Button login, cancel, register;
    database DB;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        usernameText = findViewById(R.id.username);
        passwordText = findViewById(R.id.password);
        login = findViewById(R.id.login);
        cancel = findViewById(R.id.Cancel);
        register = findViewById(R.id.register);

        DB=new database(this);

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username=usernameText.getText().toString();
                String password=passwordText.getText().toString();

                boolean result=DB.addUser(username,password);
                if(result==true) {
                    Toast.makeText(getApplicationContext(), "Registration Process Completed", Toast.LENGTH_LONG).show();
                }
                else{
                    Toast.makeText(getApplicationContext(),"User Already Exists",Toast.LENGTH_LONG).show();
                }

            }
        });

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username=usernameText.getText().toString();
                String password=passwordText.getText().toString();
                Boolean cr=DB.checkUser(new User(username,password));
                if(cr==false){
                    Toast.makeText(getApplicationContext(),"User Not Exist, Please Register First", Toast.LENGTH_LONG).show();
                }else{
//                    Toast.makeText(getApplicationContext(),"Welcome "+username,Toast.LENGTH_LONG).show();
                    startActivity(new Intent(MainActivity.this, LoginActivity.class).putExtra("username", username));
                }
            }
        });

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}