package com.example.labprogram5;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class LoginActivity extends AppCompatActivity {

    TextView welcomeTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        welcomeTextView = findViewById(R.id.textView);

        String username = getIntent().getStringExtra("username");
        welcomeTextView.setText("Welcome, " + username + "!");
    }
}