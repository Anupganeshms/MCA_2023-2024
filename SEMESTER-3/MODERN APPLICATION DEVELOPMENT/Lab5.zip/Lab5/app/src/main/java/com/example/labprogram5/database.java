package com.example.labprogram5;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.view.View;

public class database extends SQLiteOpenHelper {

//   user-db  -> Name od The Database.
//    user  -> Name of the Table having 2 columns [username(Primary Key) , password].

    public database( Context context) {
        super(context, "user-db",null,1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table user(username TEXT primary key , password TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists user");
        onCreate(db);
    }

    public boolean addUser(String username, String password) {
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues contentValues=new ContentValues();
        contentValues.put("username",username);
        contentValues.put("password",password);
        long result=db.insert("user",null,contentValues);
        if(result==-1){
            return false;
        }else{
            return true;
        }
    }

    public Boolean checkUser(User user) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cr = db.rawQuery("select * from user where username='" + user.getName() + "' and  password=='"+user.getPassword()+"'", null);
        if (cr.getCount() == 0) {
            return false;
        } else {
            return true;
        }
    }
}
