# Simple Service Worker 
- The index.html file creates frontend to register and unregister workers
- The app.js file holds the button event handlers of each button
- The sw.js file logs the message when a service is at different stage
- The Icon can be viewd in `Developer Console>Application>Manifest`
    - OR Click on Hamburgur icon in browser, and choose options like `create shortcut` or `install` to view the icon mentioned in manifest
- Note: If the activation and intialisation is not fired, try to Force Reload using `Ctrl+F5`
